// `npx @selvajs/create <dir>` — scaffold a fresh deployment.
//
// What this writes into <dir>:
//   .env                    merged from runtime's .env.example + prompt values
//   selva.config.js         copied from runtime's templates (operator can edit)
//   ecosystem.config.cjs    copied verbatim
//   package.json            depends on @selvajs/runtime + providers
//   .selva-version          marker for future CLI migrations
//   node_modules/           after `npm install`
//
// The runtime templates are the source of truth — we don't carry our own
// copies in @selvajs/create. We install @selvajs/runtime first, then copy
// from node_modules/@selvajs/runtime/templates/.

import { writeFileSync, existsSync, mkdirSync, readFileSync, cpSync } from 'node:fs';
import { resolve, join, basename } from 'node:path';
import { execSync } from 'node:child_process';
import * as p from '@clack/prompts';
import pc from 'picocolors';
import { collectConfig } from '../prompts.js';
import { generateKey } from '../secrets.js';
import { writeEnvFile } from '../env.js';
import { isEmptyOrMissing } from '../paths.js';

const CLI_VERSION = '0.1.0';

export async function runCreate(argv) {
	const { dir: rawDir, force, skipInstall } = parseArgs(argv);

	const targetDir = resolve(rawDir);
	if (!isEmptyOrMissing(targetDir) && !force) {
		console.error(
			`${pc.red('✗')} ${targetDir} already exists and isn't empty. ` +
				`Pass --force to overwrite, or choose another directory.`
		);
		process.exit(1);
	}
	mkdirSync(targetDir, { recursive: true });

	// 1. Prompt the operator. We need answers before installing because the
	//    chosen provider determines which dependencies go into package.json.
	const values = await collectConfig({ defaults: {}, mode: 'create' });

	// 2. Always generate fresh secrets for a new install. They MUST be stable
	//    across restarts; the env-merge logic below writes them once and
	//    `selva init` later refuses to regenerate them.
	values.SELVA_HMAC_KEY = generateKey();
	values.SELVA_AT_REST_KEY = generateKey();

	const deployName = basename(targetDir);

	// 3. Write package.json before installing so npm has something to read.
	const pkgJson = buildPackageJson(deployName, values);
	writeFileSync(join(targetDir, 'package.json'), pkgJson + '\n', 'utf8');

	// 4. Install. We need @selvajs/runtime on disk to copy templates from it.
	if (!skipInstall) {
		const s = p.spinner();
		s.start('Installing @selvajs/runtime and provider packages (this can take a minute)');
		try {
			execSync('npm install', { cwd: targetDir, stdio: 'pipe' });
			s.stop('Dependencies installed');
		} catch (err) {
			s.stop('npm install failed');
			throw err;
		}
	} else {
		p.log.warn(
			'--skip-install was passed: dependencies not installed. Run `npm install` manually before starting.'
		);
	}

	// 5. Now copy templates from the installed runtime and fill them in.
	const runtimeTemplates = join(targetDir, 'node_modules', '@selvajs', 'runtime', 'templates');
	if (skipInstall || !existsSync(runtimeTemplates)) {
		p.log.warn(
			`Couldn't read runtime templates from ${runtimeTemplates}. ` +
				`Run \`npm install\`, then \`selva init\` to finish setup.`
		);
		writeFileSync(join(targetDir, '.selva-version'), CLI_VERSION + '\n', 'utf8');
		p.outro(`Partial scaffold at ${pc.cyan(targetDir)}.`);
		return;
	}

	const envTemplate = readFileSync(join(runtimeTemplates, '.env.example'), 'utf8');
	writeEnvFile(join(targetDir, '.env'), envTemplate, values);

	cpSync(join(runtimeTemplates, 'selva.config.example.js'), join(targetDir, 'selva.config.js'));
	cpSync(join(runtimeTemplates, 'ecosystem.config.cjs'), join(targetDir, 'ecosystem.config.cjs'));

	writeFileSync(join(targetDir, '.selva-version'), CLI_VERSION + '\n', 'utf8');
	writeGitignore(targetDir);

	// 6. Outro with next steps.
	p.outro(
		[
			pc.green('Scaffolded ' + pc.cyan(targetDir)),
			'',
			pc.bold('Next steps:'),
			`  cd ${rawDir}`,
			`  npx selva doctor       # sanity-check the install`,
			`  npx selva start        # pm2 start ecosystem.config.cjs`,
			'',
			values.ORIGIN
				? `Then visit ${pc.cyan(values.ORIGIN)} (set up your reverse proxy first).`
				: `Then visit ${pc.cyan('http://localhost:3000')}.`
		].join('\n')
	);
}

function parseArgs(argv) {
	let dir;
	let force = false;
	let skipInstall = false;
	for (const arg of argv) {
		if (arg === '--force') force = true;
		else if (arg === '--skip-install') skipInstall = true;
		else if (arg.startsWith('--')) {
			throw new Error(`Unknown flag: ${arg}`);
		} else if (!dir) {
			dir = arg;
		} else {
			throw new Error(`Unexpected argument: ${arg}`);
		}
	}
	if (!dir) {
		throw new Error('Usage: npx @selvajs/create <directory> [--force] [--skip-install]');
	}
	return { dir, force, skipInstall };
}

// The deployment's package.json depends on @selvajs/runtime (prebuilt
// SvelteKit app) plus whichever providers the operator picked. Providers are
// imported by selva.config.js — npm needs them resolvable from node_modules.
function buildPackageJson(name, values) {
	const deps = {
		'@selvajs/platform': 'latest',
		'@selvajs/runtime': 'latest'
	};

	const providers = new Set([
		values.SELVA_AUTH_PROVIDER,
		values.SELVA_DATA_PROVIDER,
		values.SELVA_STORAGE_PROVIDER
	]);

	if (providers.has('local')) deps['@selvajs/local-provider'] = 'latest';
	if (providers.has('supabase')) deps['@selvajs/supabase-provider'] = 'latest';
	if (providers.has('header')) deps['@selvajs/header-auth-provider'] = 'latest';

	const pkg = {
		name: sanitizePackageName(name),
		version: '0.1.0',
		private: true,
		type: 'module',
		scripts: {
			start: 'pm2 start ecosystem.config.cjs',
			stop: 'pm2 stop selva-compute',
			restart: 'pm2 restart selva-compute --update-env',
			logs: 'pm2 logs selva-compute'
		},
		dependencies: deps
	};
	return JSON.stringify(pkg, null, 2);
}

function sanitizePackageName(name) {
	// npm package names: lowercase, no spaces, limited punctuation.
	return (
		name
			.toLowerCase()
			.replace(/[^a-z0-9._-]+/g, '-')
			.replace(/^[-._]+|[-._]+$/g, '') || 'selva-deployment'
	);
}

function writeGitignore(dir) {
	const path = join(dir, '.gitignore');
	if (existsSync(path)) return;
	writeFileSync(
		path,
		['node_modules/', '.env', '.env.local', '.selva-data/', 'logs/', '*.log', ''].join('\n'),
		'utf8'
	);
}
